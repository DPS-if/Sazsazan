using Godot;
using System;

public partial class PauseMenu : CanvasLayer
{
	public override void _Ready()
	{
		GetTree().Paused = true;
		var resumeBtn = GetNode<Button>("Panel/resume_btn");
		resumeBtn.Pressed += () =>
		{
			GetTree().Paused = false;
			QueueFree(); 
		};
		var quitBtn = GetNode<Button>("Panel/quit_btn");
		quitBtn.Pressed += () =>
		{
			GetTree().Quit();
		};
	}
}
